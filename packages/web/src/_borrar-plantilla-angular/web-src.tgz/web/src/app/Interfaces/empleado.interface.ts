/**
 * La persona que trabaja en el laboratorio, exista o no una cuenta de
 * usuario para ella. Es el espejo de core.empleado.
 *
 * empleado y usuario son DOS COSAS. El empleado es la persona; el usuario
 * es la credencial con la que entra al sistema. Hay empleados sin usuario
 * -- el motorista, la senora del aseo -- y por eso se crean por separado:
 * primero existe la persona, despues, si hace falta, se le da una cuenta.
 */
export interface Empleado {
  empleadoId: number;
  nombres: string;
  apellidos: string;
  /** Numero de identidad. Opcional: no todos lo traen el primer dia. */
  documento: string | null;
  telefono: string | null;
  correo: string | null;
  cargo: string | null;
  /** Del bioquimico o del medico. Va impreso en el informe junto a la firma. */
  numeroColegiacion: string | null;
  activo: boolean;
  creadoEn: string;
  /** Si ya tiene cuenta para entrar al sistema. Lo pone el back. */
  username: string | null;
  /** El id de esa cuenta. Hace falta para cambiarle las sedes. */
  usuarioId: number | null;
  /**
   * Las sedes donde puede pararse.
   *
   * null = no tiene cuenta. [] = tiene cuenta y no le dieron ninguna sede,
   * que no es lo mismo: con [] la persona puede activar su clave y aun asi
   * no entrar a ningun lado.
   */
  sucursales: number[] | null;
}

/** Lo que se manda al crear o editar. Sin id, sin fechas, sin empresa. */
export interface EmpleadoEntrada {
  nombres: string;
  apellidos: string;
  documento: string | null;
  telefono: string | null;
  correo: string | null;
  cargo: string | null;
  numeroColegiacion: string | null;
  activo: boolean;
}

/** Un rol de la empresa, para el desplegable del formulario. */
export interface Rol {
  rolId: number;
  nombre: string;
  descripcion: string | null;
  esSistema: boolean;
}

/** La parte opcional de crear: darle cuenta para entrar al sistema. */
export interface CuentaNueva {
  username: string;
  rolId: number;
  /** Al menos una: sin sedes, la cuenta nace sin poder entrar. */
  sucursales: number[];
}

/** Una sede abierta de la empresa, para las casillas del formulario. */
export interface Sucursal {
  sucursalId: number;
  codigo: string;
  nombre: string;
}

/**
 * Lo que devuelve POST /empleados.
 *
 * El codigo viene EN CLARO y es la unica vez que existe: en la base solo
 * queda su hash argon2. No hay pantalla de "verlo otra vez" ni la va a
 * haber. Si se pierde, se genera otro.
 */
export interface RespuestaCrearEmpleado extends Empleado {
  activacion: {
    codigo: string;
    venceEn: string;
    aviso: string;
  } | null;
}
