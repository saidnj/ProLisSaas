import { Component, computed, inject, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { NgSelectComponent } from '@ng-select/ng-select';
import { Encabezado } from '../../encabezado/encabezado';
import { EmpleadosService } from '../../../Servicios/empleados.service';
import { mensajeDeError } from '../../../Servicios/errores';
import type { EmpleadoEntrada, Rol, Sucursal } from '../../../Interfaces/empleado.interface';

/**
 * CREAR Y EDITAR, EN UNA SOLA PANTALLA.
 *
 * Son el mismo formulario con los mismos campos y las mismas reglas: tenerlos
 * separados significa que el dia que se agregue un campo hay que acordarse de
 * dos sitios, y uno de los dos se olvida.
 *
 * Lo que cambia entre crear y editar es la cuenta:
 *
 *   crear   aparece la seccion entera -- usuario, rol y sedes -- y es
 *           opcional: no todo empleado necesita entrar al sistema.
 *
 *   editar  el usuario y el rol NO se tocan aqui (son decisiones con sus
 *           propias reglas), pero las SEDES si: es lo que mas cambia en el
 *           dia a dia -- alguien se traslada, cubre una semana en otra sede.
 */
@Component({
  selector: 'app-formulario-empleado',
  imports: [ReactiveFormsModule, RouterLink, NgTemplateOutlet, NgSelectComponent, Encabezado],
  templateUrl: './formulario-empleado.html',
  styleUrl: './formulario-empleado.scss',
})
export class FormularioEmpleado {
  
  private readonly fb = inject(FormBuilder);
  private readonly servicio = inject(EmpleadosService);
  private readonly router = inject(Router);
  private readonly ruta = inject(ActivatedRoute);

  private readonly param = this.ruta.snapshot.paramMap.get('id');
  protected readonly id = this.param ? Number(this.param) : null;
  protected readonly editando = this.id !== null;

  protected readonly cargando = signal(this.editando);
  protected readonly guardando = signal(false);
  protected readonly error = signal<string | null>(null);
  protected readonly roles = signal<Rol[]>([]);
  protected readonly sedes = signal<Sucursal[]>([]);
  protected readonly copiado = signal(false);

  /** La cuenta del empleado que se esta editando. null si no tiene. */
  protected readonly usuarioId = signal<number | null>(null);
  protected readonly username = signal<string | null>(null);

  /**
   * Las sedes marcadas. Un Set y no un FormArray: lo unico que hace falta es
   * "esta o no esta", y un Set lo dice sin indices que mantener sincronizados
   * con el orden de la lista.
   */
  protected readonly elegidas = signal<ReadonlySet<number>>(new Set());
  private sedesOriginales: ReadonlySet<number> = new Set();

  protected readonly codigoNuevo = signal<{
    codigo: string; venceEn: string; empleadoId: number; nombre: string;
  } | null>(null);

  protected readonly titulo = computed(() =>
    this.editando ? 'Editar empleado' : 'Nuevo empleado',
  );

  protected readonly formulario = this.fb.nonNullable.group({
    nombres:   ['', [Validators.required, Validators.maxLength(80)]],
    apellidos: ['', [Validators.required, Validators.maxLength(80)]],
    documento: [''],
    telefono:  [''],
    correo:    ['', [Validators.email]],
    cargo:     [''],
    numeroColegiacion: [''],
    activo:    [true],

    // La cuenta. Al editar solo se usa 'motivo'.
    crearCuenta: [false],
    username:    [''],
    rolId:       [null as number | null],
    motivo:      [''],
  });

  /** Si esta pantalla tiene que pedir sedes. */
  protected readonly pideSedes = computed(() =>
    this.editando ? this.usuarioId() !== null : this.formulario.get('crearCuenta')!.value,
  );

  /** Se desmarco alguna que estaba: ahi tiene sentido preguntar por que. */
  protected readonly hayRetiros = computed(() =>
    [...this.sedesOriginales].some((s) => !this.elegidas().has(s)),
  );

  protected readonly faltaUsuario = computed(() => {
    const v = String(this.formulario.get('username')!.value ?? '').trim();
    return !this.editando && this.formulario.get('crearCuenta')!.value && v.length < 3;
  });

  protected readonly faltaRol = computed(() =>
    !this.editando &&
    this.formulario.get('crearCuenta')!.value &&
    !Number(this.formulario.get('rolId')!.value),
  );

  protected readonly faltanSedes = computed(
    () => this.pideSedes() && this.elegidas().size === 0,
  );

  constructor() {
    // Las sedes hacen falta en los dos casos: al crear para elegirlas, al
    // editar para poder cambiarlas.
    this.servicio.listarSucursales().subscribe({
      next: (s) => this.sedes.set(s),
      error: () => this.sedes.set([]),
    });

    if (this.id !== null) {
      this.servicio.obtener(this.id).subscribe({
        next: (e) => {
          this.formulario.patchValue({
            nombres: e.nombres,
            apellidos: e.apellidos,
            // Los nulos de la base se vuelven '' en el formulario: un input
            // con null adentro se queda pegado y Angular se queja.
            documento: e.documento ?? '',
            telefono: e.telefono ?? '',
            correo: e.correo ?? '',
            cargo: e.cargo ?? '',
            numeroColegiacion: e.numeroColegiacion ?? '',
            activo: e.activo,
          });
          this.usuarioId.set(e.usuarioId);
          this.username.set(e.username);
          this.sedesOriginales = new Set(e.sucursales ?? []);
          this.elegidas.set(new Set(this.sedesOriginales));
          this.cargando.set(false);
        },
        error: (e) => {
          this.error.set(mensajeDeError(e, 'No se encontro ese empleado'));
          this.cargando.set(false);
        },
      });
    } else {
      this.servicio.listarRoles().subscribe({
        next: (r) => this.roles.set(r),
        error: () => this.roles.set([]),
      });
    }
  }

  protected alternarSede(id: number): void {
    const s = new Set(this.elegidas());
    if (s.has(id)) s.delete(id); else s.add(id);
    this.elegidas.set(s);
  }

  protected malo(campo: string): boolean {
    const c = this.formulario.get(campo);
    return !!c && c.invalid && (c.touched || c.dirty);
  }

  protected async copiar(): Promise<void> {
    const c = this.codigoNuevo();
    if (!c) return;
    try {
      await navigator.clipboard.writeText(c.codigo);
      this.copiado.set(true);
      setTimeout(() => this.copiado.set(false), 2000);
    } catch {
      // Sin permiso de portapapeles (o sin HTTPS): el codigo esta a la vista
      // y se puede seleccionar a mano. No es motivo para avisar nada.
    }
  }

  protected terminar(): void {
    const c = this.codigoNuevo();
    void this.router.navigate(['/empleados', c ? c.empleadoId : '']);
  }

  protected guardar(): void {
    if (this.formulario.invalid || this.guardando()) {
      this.formulario.markAllAsTouched();
      return;
    }
    if (this.faltaUsuario() || this.faltaRol() || this.faltanSedes()) {
      this.formulario.markAllAsTouched();
      return;
    }

    this.guardando.set(true);
    this.error.set(null);

    const v = this.formulario.getRawValue();

    // Al reves que al cargar: '' vuelve a ser null. Un texto vacio en la base
    // es un dato que dice "esto esta en blanco"; null dice "no se sabe". No
    // son lo mismo, y mezclarlos ensucia las consultas para siempre.
    const datos: EmpleadoEntrada = {
      nombres: v.nombres.trim(),
      apellidos: v.apellidos.trim(),
      documento: v.documento.trim() || null,
      telefono: v.telefono.trim() || null,
      correo: v.correo.trim() || null,
      cargo: v.cargo.trim() || null,
      numeroColegiacion: v.numeroColegiacion.trim() || null,
      activo: v.activo,
    };

    if (this.id !== null) {
      this.guardarEdicion(this.id, datos, v.motivo.trim());
      return;
    }

    this.servicio
      .crear({
        ...datos,
        ...(v.crearCuenta
          ? {
              usuario: {
                username: v.username.trim().toLowerCase(),
                rolId: Number(v.rolId),
                sucursales: [...this.elegidas()],
              },
            }
          : {}),
      })
      .subscribe({
        next: (e) => {
          this.guardando.set(false);

          // Si vino codigo, NO se navega: hay que mostrarlo primero, porque
          // de la base solo sale el hash y no hay segunda oportunidad.
          if (e.activacion) {
            this.codigoNuevo.set({
              codigo: e.activacion.codigo,
              venceEn: e.activacion.venceEn,
              empleadoId: e.empleadoId,
              nombre: e.nombres + ' ' + e.apellidos,
            });
            return;
          }

          void this.router.navigate(['/empleados', e.empleadoId]);
        },
        error: (e) => {
          this.guardando.set(false);
          this.error.set(mensajeDeError(e, 'No se pudo crear el empleado'));
        },
      });
  }

  /**
   * Editar son DOS peticiones, y no es un descuido.
   *
   * Los datos del empleado y las sedes donde puede entrar son dos cosas
   * distintas -- una es la ficha de la persona, la otra es un permiso -- y
   * tienen que poder distinguirse en la auditoria. Por eso van por rutas
   * separadas y no en un solo "guardar" que las mezcle.
   *
   * La consecuencia hay que decirla cuando ocurre: si la primera pasa y la
   * segunda falla, los datos SI quedaron guardados. Callarlo seria dejar al
   * usuario creyendo que no se guardo nada y que puede reintentar de cero.
   */
  private guardarEdicion(id: number, datos: EmpleadoEntrada, motivo: string): void {
    this.servicio.actualizar(id, datos).subscribe({
      next: () => {
        const uid = this.usuarioId();
        const cambiaron =
          uid !== null &&
          (this.elegidas().size !== this.sedesOriginales.size ||
            [...this.elegidas()].some((s) => !this.sedesOriginales.has(s)));

        if (!cambiaron) {
          this.guardando.set(false);
          void this.router.navigate(['/empleados', id]);
          return;
        }

        this.servicio.fijarAccesos(uid!, [...this.elegidas()], motivo || undefined).subscribe({
          next: () => {
            this.guardando.set(false);
            void this.router.navigate(['/empleados', id]);
          },
          error: (e) => {
            this.guardando.set(false);
            this.error.set(
              'Los datos del empleado SI se guardaron, pero no se pudieron cambiar ' +
                'las sedes: ' + mensajeDeError(e, 'error desconocido'),
            );
          },
        });
      },
      error: (e) => {
        this.guardando.set(false);
        this.error.set(mensajeDeError(e, 'No se pudo guardar'));
      },
    });
  }
}
