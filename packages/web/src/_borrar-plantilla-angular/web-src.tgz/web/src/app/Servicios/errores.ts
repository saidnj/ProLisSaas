import { HttpErrorResponse } from '@angular/common/http';

/**
 * Saca un mensaje legible de lo que sea que haya vuelto.
 *
 * Nest contesta de dos formas segun quien rechazo:
 *   - una excepcion nuestra  -> message es un string
 *   - el ValidationPipe      -> message es un ARREGLO de strings
 * y si el back no esta levantado no hay cuerpo ninguno (status 0).
 */
export function mensajeDeError(err: unknown, porOmision = 'Algo salio mal'): string {
  if (!(err instanceof HttpErrorResponse)) return porOmision;

  if (err.status === 0) {
    return 'No se pudo hablar con el servidor. Revisa que el API este levantado.';
  }

  const m = (err.error as { message?: string | string[] } | null)?.message;
  if (Array.isArray(m)) return m.join('. ');
  if (typeof m === 'string' && m.trim()) return m;

  return porOmision;
}
