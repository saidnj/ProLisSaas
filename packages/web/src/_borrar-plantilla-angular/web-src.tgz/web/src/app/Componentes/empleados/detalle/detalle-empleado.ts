import { Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Encabezado } from '../../encabezado/encabezado';
import { EmpleadosService } from '../../../Servicios/empleados.service';
import { SesionService } from '../../../Servicios/sesion.service';
import { mensajeDeError } from '../../../Servicios/errores';
import type { Empleado, Sucursal } from '../../../Interfaces/empleado.interface';

/** Ver los datos, sin poder tocarlos. La pantalla que no hace dano. */
@Component({
  selector: 'app-detalle-empleado',
  imports: [RouterLink, DatePipe, Encabezado],
  templateUrl: './detalle-empleado.html',
  styleUrl: './detalle-empleado.scss',
})
export class DetalleEmpleado {
  private readonly servicio = inject(EmpleadosService);
  private readonly ruta = inject(ActivatedRoute);
  protected readonly sesion = inject(SesionService);

  protected readonly empleado = signal<Empleado | null>(null);
  protected readonly cargando = signal(true);
  protected readonly error = signal<string | null>(null);

  protected readonly puedeAdministrar = computed(
    () => this.sesion.puede('usuario.administrar'),
  );

  protected readonly id = Number(this.ruta.snapshot.paramMap.get('id'));

  private readonly sedes = signal<Sucursal[]>([]);

  /**
   * Los ids de sus sedes, convertidos a codigo y nombre.
   *
   * El back manda ids porque es lo que el formulario necesita para marcar
   * casillas; aqui hacen falta los nombres. Se cruzan en el front y no se le
   * piden al back dos veces la misma cosa en dos formas distintas.
   */
  protected readonly susSedes = computed(() => {
    const ids = this.empleado()?.sucursales;
    if (!ids) return [];
    return this.sedes().filter((s) => ids.includes(s.sucursalId));
  });

  constructor() {
    this.servicio.listarSucursales().subscribe({
      next: (s) => this.sedes.set(s),
      error: () => this.sedes.set([]),
    });

    this.servicio.obtener(this.id).subscribe({
      next: (e) => {
        this.empleado.set(e);
        this.cargando.set(false);
      },
      error: (e) => {
        this.error.set(mensajeDeError(e, 'No se encontro ese empleado'));
        this.cargando.set(false);
      },
    });
  }
}
