import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import type {
  Empleado, EmpleadoEntrada, RespuestaCrearEmpleado, Rol, Sucursal,
} from '../Interfaces/empleado.interface';

/**
 * Empleados, contra el API de verdad.
 *
 * Ya no hay datos de muestra: todo sale de la base, recortado por RLS a la
 * empresa de quien pregunta. Ninguna de estas llamadas manda el empresaId
 * -- ni podria: el back lo saca del token firmado y no le cree al navegador.
 *
 * El token lo pega el tokenInterceptor, asi que aqui no aparece.
 */
@Injectable({ providedIn: 'root' })
export class EmpleadosService {
  private readonly api = inject(ApiService);

  listar(): Observable<Empleado[]> {
    return this.api.get<Empleado[]>('empleados');
  }

  obtener(id: number): Observable<Empleado> {
    return this.api.get<Empleado>('empleados/' + id);
  }

  /**
   * Crea el empleado y, si viene `usuario`, tambien su cuenta y su codigo de
   * activacion -- las tres cosas en una sola transaccion del lado del back.
   * Si algo falla, no queda nada a medias.
   */
  crear(
    datos: EmpleadoEntrada & {
      usuario?: { username: string; rolId: number; sucursales: number[] };
    },
  ): Observable<RespuestaCrearEmpleado> {
    return this.api.post<RespuestaCrearEmpleado>('empleados', datos);
  }

  /** PATCH y no PUT: en este sistema nada se reemplaza entero. */
  actualizar(id: number, datos: EmpleadoEntrada): Observable<Empleado> {
    return this.api.patch<Empleado>('empleados/' + id, datos);
  }

  /** Los roles de la empresa, para el desplegable. */
  listarRoles(): Observable<Rol[]> {
    return this.api.get<Rol[]>('roles');
  }

  /** Las sedes ABIERTAS de la empresa, para las casillas. */
  listarSucursales(): Observable<Sucursal[]> {
    return this.api.get<Sucursal[]>('sucursales');
  }

  /**
   * En que sedes queda parado un usuario. Es el conjunto COMPLETO: lo que no
   * venga se retira -- con motivo, y sin borrar la fila.
   *
   * Va por su propia ruta y no dentro del PATCH del empleado a proposito:
   * cambiar donde puede entrar alguien es una decision de permisos, no un
   * dato de la ficha, y tiene que poder distinguirse en la auditoria.
   */
  fijarAccesos(usuarioId: number, sucursales: number[], motivo?: string) {
    return this.api.put<{ usuarioId: number; sucursales: number[]; retiradas: number[] }>(
      'usuarios/' + usuarioId + '/sucursales',
      { sucursales, ...(motivo ? { motivo } : {}) },
    );
  }
}
