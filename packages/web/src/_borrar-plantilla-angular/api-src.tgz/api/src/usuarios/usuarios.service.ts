import {
  BadRequestException, ForbiddenException, Injectable, NotFoundException,
} from '@nestjs/common';
import * as argon2 from 'argon2';
import { PrismaService } from '../prisma/prisma.service';
import type { Sesion } from '../comun/sesion';
import { generarCodigo } from '../comun/codigo';
import { CrearUsuarioDto } from './dto/crear-usuario.dto';
import { FijarAccesosDto } from './dto/fijar-accesos.dto';

const HORAS_DE_VIDA = 24;

@Injectable()
export class UsuariosService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Crea el usuario y devuelve su codigo de activacion EN CLARO.
   *
   * Es la unica vez que ese codigo existe fuera de un hash. No se guarda, no
   * se puede volver a pedir, no hay pantalla de "ver el codigo otra vez". Si
   * el admin lo pierde, genera otro con resetear().
   *
   * Las dos escrituras van en la MISMA transaccion: un usuario creado sin su
   * codigo seria una cuenta que nadie puede estrenar.
   */
  async crear(sesion: Sesion, dto: CrearUsuarioDto) {
    const codigo = generarCodigo();
    // SOBRE codigo.paraHash, no sobre codigo.legible: activar() normaliza
    // antes de verificar, asi que el hash tiene que ir sobre la forma
    // canonica. Hasheando la legible ningun codigo cuadraria nunca.
    const codigoHash = await argon2.hash(codigo.paraHash, { type: argon2.argon2id });

    const r = await this.prisma.conSesion(sesion, async (tx) => {
      const [creado] = await tx.$queryRaw<{ crear_usuario: bigint }[]>`
        SELECT core.crear_usuario(${BigInt(dto.empleadoId)}, ${BigInt(dto.rolId)},
                                  ${dto.username})`;

      const [act] = await tx.$queryRaw<{ activacion_id: bigint; vence_en: Date }[]>`
        SELECT * FROM core.generar_activacion(${creado.crear_usuario},
                                              ${codigoHash}, ${HORAS_DE_VIDA})`;

      return { usuarioId: creado.crear_usuario, venceEn: act.vence_en };
    });

    return {
      usuarioId: Number(r.usuarioId),
      username: dto.username,
      codigo: codigo.legible, // <- en claro, UNA sola vez
      venceEn: r.venceEn,
      aviso: 'Este codigo no se vuelve a mostrar. Entregaselo a la persona.',
    };
  }

  /**
   * Resetea la clave de alguien: mismo mecanismo, sin nada nuevo.
   *
   * El usuario vuelve a pendiente_activacion y queda FUERA EN EL ACTO. Es a
   * proposito: un solo camino para estrenar una clave, y un camino no se
   * olvida de mantener.
   */
  async resetear(sesion: Sesion, usuarioId: number) {
    const codigo = generarCodigo();
    // SOBRE codigo.paraHash, no sobre codigo.legible: activar() normaliza
    // antes de verificar, asi que el hash tiene que ir sobre la forma
    // canonica. Hasheando la legible ningun codigo cuadraria nunca.
    const codigoHash = await argon2.hash(codigo.paraHash, { type: argon2.argon2id });

    const r = await this.prisma.conSesion(sesion, async (tx) => {
      const [act] = await tx.$queryRaw<{ activacion_id: bigint; vence_en: Date }[]>`
        SELECT * FROM core.generar_activacion(${BigInt(usuarioId)},
                                              ${codigoHash}, ${HORAS_DE_VIDA})`;
      return act;
    });

    return {
      usuarioId,
      codigo: codigo.legible,
      venceEn: r.vence_en,
      aviso: 'La persona quedo fuera hasta que active con este codigo.',
    };
  }

  /**
   * EN QUE SEDES QUEDA PARADO UN USUARIO.
   *
   * Recibe el conjunto completo y lo deja igual: activa las marcadas, retira
   * las que ya no vienen. Las dos cosas en UNA transaccion -- si retirara y
   * despues fallara al dar, el usuario quedaria sin ninguna sede y sin poder
   * entrar, que es justo lo que no puede pasar.
   *
   * Retirar es un UPDATE con motivo, nunca un DELETE: que en marzo Gabriela
   * pudiera entrar a la sede Norte es un hecho que paso, y borrarlo no lo
   * deshace, solo lo esconde.
   */
  async fijarAccesos(sesion: Sesion, usuarioId: number, dto: FijarAccesosDto) {
    return this.prisma.conSesion(sesion, async (tx) => {
      const [permiso] = await tx.$queryRaw<{ puede: boolean }[]>`
        SELECT core.usuario_puede('usuario.administrar') AS puede`;
      if (!permiso?.puede) {
        throw new ForbiddenException('No tenes permiso para cambiar accesos');
      }
      // El ::text porque exigir_permiso() devuelve void y Prisma no sabe
      // deserializar ese tipo.
      await tx.$queryRaw`SELECT core.exigir_permiso('usuario.administrar')::text AS ok`;

      // Sin WHERE empresa_id: si el usuario es de otro laboratorio, RLS hace
      // que no exista. Por eso 404 y no 403 -- un 403 confirmaria que ese id
      // existe en algun lado.
      const existe = await tx.$queryRaw<{ usuario_id: bigint }[]>`
        SELECT usuario_id FROM core.usuario WHERE usuario_id = ${BigInt(usuarioId)}`;
      if (existe.length === 0) throw new NotFoundException('No existe ese usuario');

      const lista = '{' + dto.sucursales.join(',') + '}';
      const motivo = dto.motivo?.trim() || 'retirado desde la administracion de usuarios';

      // 1 - Retirar las que ya no vienen. El motivo es obligatorio por el
      //     CHECK ck_acceso_motivo, asi que si no lo mandan va uno generico.
      const retiradas = await tx.$queryRaw<{ sucursal_id: bigint }[]>`
        UPDATE core.acceso_sucursal
           SET activo = false, retirado_en = now(), retirado_motivo = ${motivo}
         WHERE usuario_id = ${BigInt(usuarioId)}
           AND activo
           AND NOT (sucursal_id = ANY(${lista}::bigint[]))
        RETURNING sucursal_id`;

      // 2 - Dar las marcadas. ON CONFLICT porque la que se retiro alguna vez
      //     ya tiene su fila: volver a darle acceso es revivir esa misma
      //     fila, no crear otra.
      const dadas = await tx.$queryRaw<{ sucursal_id: bigint }[]>`
        INSERT INTO core.acceso_sucursal (usuario_id, sucursal_id, empresa_id)
        SELECT ${BigInt(usuarioId)}, s.sucursal_id, s.empresa_id
          FROM core.sucursal s
         WHERE s.sucursal_id = ANY(${lista}::bigint[])
           AND s.activo
        ON CONFLICT (usuario_id, sucursal_id) DO UPDATE
           SET activo = true, retirado_en = NULL, retirado_motivo = NULL
        RETURNING core.acceso_sucursal.sucursal_id`;

      // Puede pasar si mandan ids que no existen o de sedes cerradas. Se
      // lanza ANTES del COMMIT, asi que el retiro del paso 1 tambien se
      // deshace: nadie queda encerrado afuera por un id mal escrito.
      if (dadas.length === 0) {
        throw new BadRequestException(
          'Ninguna de esas sucursales existe o esta abierta en tu empresa',
        );
      }

      return {
        usuarioId,
        sucursales: dadas.map((x) => Number(x.sucursal_id)).sort((a, b) => a - b),
        retiradas: retiradas.map((x) => Number(x.sucursal_id)),
      };
    });
  }
}
