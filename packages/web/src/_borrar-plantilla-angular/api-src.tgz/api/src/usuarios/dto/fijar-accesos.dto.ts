import { Type } from 'class-transformer';
import {
  ArrayNotEmpty, IsArray, IsInt, IsOptional, IsPositive, IsString, MaxLength,
} from 'class-validator';

/**
 * En que sedes queda parado un usuario. Es el conjunto COMPLETO: lo que no
 * venga en el arreglo se retira.
 *
 * Es lo que le sirve a una pantalla de casillas -- el admin marca, desmarca
 * y guarda -- pero significa que un arreglo incompleto quita accesos. Mismo
 * trato que core.asignar_permisos_a_rol().
 */
export class FijarAccesosDto {
  @IsArray()
  @ArrayNotEmpty({ message: 'Un usuario tiene que quedar con al menos una sucursal' })
  @Type(() => Number)
  @IsInt({ each: true })
  @IsPositive({ each: true })
  sucursales!: number[];

  /** Por que se le quitaron sedes. Si no viene, se guarda uno generico. */
  @IsOptional()
  @IsString()
  @MaxLength(200)
  motivo?: string;
}
