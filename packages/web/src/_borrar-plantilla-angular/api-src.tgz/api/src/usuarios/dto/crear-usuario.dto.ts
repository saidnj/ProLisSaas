import { IsInt, IsString, Matches, MaxLength, MinLength } from 'class-validator';

export class CrearUsuarioDto {
  @IsInt()
  empleadoId!: number;

  @IsInt()
  rolId!: number;

  /** El mismo CHECK que tiene la base: ck_usuario_username. */
  @IsString()
  @MinLength(3)
  @MaxLength(40)
  @Matches(/^[a-z0-9._-]+$/, {
    message: 'El usuario solo admite minusculas, numeros, punto, guion y guion bajo',
  })
  username!: string;
}
