import { Body, Controller, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { UsuariosService } from './usuarios.service';
import { CrearUsuarioDto } from './dto/crear-usuario.dto';
import { FijarAccesosDto } from './dto/fijar-accesos.dto';
import { SesionActual } from '../comun/sesion.decorador';
// 'import type' y no 'import' a secas: con isolatedModules y
// emitDecoratorMetadata, TypeScript exige que los tipos que aparecen en una
// firma decorada se importen como tipos. Si no, intenta emitir metadata de
// runtime para una interfaz que en runtime no existe.
import type { Sesion } from '../comun/sesion';

/**
 * Sin @Publico(): las dos rutas exigen token. Y el permiso
 * usuario.administrar lo comprueba la BASE, adentro de core.crear_usuario()
 * y core.generar_activacion() -- no aqui. Si se comprobara solo aqui,
 * bastaria una ruta nueva que alguien olvide proteger.
 */
@Controller('usuarios')
export class UsuariosController {
  constructor(private readonly usuarios: UsuariosService) {}

  @Post()
  crear(@SesionActual() sesion: Sesion, @Body() dto: CrearUsuarioDto) {
    return this.usuarios.crear(sesion, dto);
  }

  @Post(':id/resetear-clave')
  resetear(@SesionActual() sesion: Sesion, @Param('id', ParseIntPipe) id: number) {
    return this.usuarios.resetear(sesion, id);
  }

  /**
   * PUT /usuarios/:id/sucursales - en que sedes queda parado.
   *
   * PUT y no PATCH a proposito: se manda el conjunto COMPLETO y queda tal
   * cual. Lo que no venga, se retira. Es lo que le sirve a una pantalla de
   * casillas, y el verbo lo dice.
   */
  @Put(':id/sucursales')
  fijarAccesos(
    @SesionActual() sesion: Sesion,
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: FijarAccesosDto,
  ) {
    return this.usuarios.fijarAccesos(sesion, id, dto);
  }
}
