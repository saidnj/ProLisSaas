import {
  BadRequestException, ForbiddenException, Injectable, NotFoundException,
} from '@nestjs/common';
import * as argon2 from 'argon2';
import { PrismaService } from '../prisma/prisma.service';
import type { Tx } from '../prisma/prisma.service';
import type { Sesion } from '../comun/sesion';
import { generarCodigo } from '../comun/codigo';
import { CrearEmpleadoDto } from './dto/crear-empleado.dto';
import { ActualizarEmpleadoDto } from './dto/actualizar-empleado.dto';

/** Lo que devuelve la lista. Mismo molde que el front (Interfaces/empleado.interface.ts). */
export interface EmpleadoDeLista {
  empleadoId: number;
  nombres: string;
  apellidos: string;
  documento: string | null;
  telefono: string | null;
  correo: string | null;
  cargo: string | null;
  numeroColegiacion: string | null;
  activo: boolean;
  creadoEn: string;
  /** El username de su cuenta, o null si no tiene. */
  username: string | null;
  /** El id de su cuenta. Lo necesita el front para PUT /usuarios/:id/sucursales. */
  usuarioId: number | null;
  /** Las sedes donde puede pararse. null cuando no tiene cuenta. */
  sucursales: number[] | null;
}

export interface SucursalDeLista {
  sucursalId: number;
  codigo: string;
  nombre: string;
}

export interface RolDeLista {
  rolId: number;
  nombre: string;
  descripcion: string | null;
  esSistema: boolean;
}

/** El mismo jsonb para listar, obtener, crear y editar: una sola forma. */
const FORMA_EMPLEADO = `
  jsonb_build_object(
    'empleadoId',        e.empleado_id,
    'nombres',           e.nombres,
    'apellidos',         e.apellidos,
    'documento',         e.documento,
    'telefono',          e.telefono,
    'correo',            e.correo,
    'cargo',             e.cargo,
    'numeroColegiacion', e.numero_colegiacion,
    'activo',            e.activo,
    'creadoEn',          e.creado_en,
    'username',          u.username,
    'usuarioId',         u.usuario_id,

    -- Las sedes donde puede pararse. null cuando no tiene cuenta -- que no
    -- es lo mismo que [], "tiene cuenta y no le dieron ninguna sede".
    'sucursales',        CASE WHEN u.usuario_id IS NULL THEN NULL ELSE (
                           SELECT coalesce(jsonb_agg(a.sucursal_id ORDER BY a.sucursal_id),
                                           '[]'::jsonb)
                           FROM core.acceso_sucursal a
                           WHERE a.usuario_id = u.usuario_id
                             AND a.empresa_id = u.empresa_id
                             AND a.activo
                         ) END
  )`;

/** El FROM que acompana a FORMA_EMPLEADO. */
const DESDE_EMPLEADO = `
  FROM core.empleado e
  LEFT JOIN core.usuario u
         ON u.empleado_id = e.empleado_id
        AND u.empresa_id  = e.empresa_id`;

@Injectable()
export class EmpleadosService {
  constructor(private readonly prisma: PrismaService) {}

  // ===================================================================
  //  LISTAR
  // ===================================================================
  async listar(sesion: Sesion): Promise<EmpleadoDeLista[]> {
    return this.prisma.conSesion(sesion, async (tx) => {
      await this.exigirAdministrar(tx);

      // Mira bien lo que NO lleva: ningun "WHERE empresa_id". No hace falta
      // -- la politica rls_empleado_ver se lo agrega Postgres a esta
      // consulta y a cualquier otra, la escriba quien la escriba.
      //
      // El LEFT JOIN a core.usuario si lleva las DOS columnas (empleado_id
      // Y empresa_id), que es la regla de la casa para toda llave foranea
      // compuesta. Aqui RLS ya recorta las dos tablas a la misma empresa,
      // asi que es redundante -- pero el dia que esta consulta se copie
      // dentro de una funcion SECURITY DEFINER, donde RLS no aplica, esa
      // linea es lo unico que impide cruzar empresas.
      //
      // Y sale como jsonb porque adentro de un jsonb los bigint salen como
      // numeros de JSON: no hay que convertir BigInt a Number campo por
      // campo ni explota JSON.stringify.
      const [fila] = await tx.$queryRawUnsafe<{ lista: EmpleadoDeLista[] }[]>(`
        SELECT coalesce(
                 jsonb_agg(x ORDER BY x->>'apellidos', x->>'nombres'),
                 '[]'::jsonb
               ) AS lista
        FROM (SELECT ${FORMA_EMPLEADO} AS x ${DESDE_EMPLEADO}) q`);

      return fila?.lista ?? [];
    });
  }

  // ===================================================================
  //  UNO SOLO
  // ===================================================================
  async obtener(sesion: Sesion, id: number): Promise<EmpleadoDeLista> {
    return this.prisma.conSesion(sesion, async (tx) => {
      await this.exigirAdministrar(tx);

      const [fila] = await tx.$queryRawUnsafe<{ empleado: EmpleadoDeLista | null }[]>(
        `SELECT ${FORMA_EMPLEADO} AS empleado ${DESDE_EMPLEADO} WHERE e.empleado_id = $1`,
        BigInt(id),
      );

      // Si es de otra empresa, RLS no lo oculta a medias: no existe. Por eso
      // "no encontrado" y no "no tenes permiso" -- un 403 aqui le diria a
      // quien pregunta que ese id SI existe en algun lado, que es justo lo
      // que no queremos contarle.
      if (!fila?.empleado) throw new NotFoundException('No existe ese empleado');

      return fila.empleado;
    });
  }

  // ===================================================================
  //  CREAR - el empleado, y si se pide, su cuenta y su codigo
  //
  //  Tres escrituras encadenadas que no sirven de a una:
  //
  //    INSERT core.empleado          -> sale el empleado_id
  //    core.crear_usuario(...)       -> usa ese id, sale el usuario_id
  //    core.generar_activacion(...)  -> usa ese id, sale el codigo
  //
  //  Si la tercera falla, un usuario sin codigo es una cuenta que nadie
  //  puede estrenar y que nadie puede arreglar desde la pantalla. Por eso
  //  van en UNA transaccion: o pasan las tres o no pasa ninguna.
  //
  //  Funciona encadenado porque dentro de una transaccion cada consulta ve
  //  lo que escribieron las anteriores: crear_usuario() encuentra el
  //  empleado que acabamos de insertar aunque todavia no haya COMMIT.
  // ===================================================================
  async crear(sesion: Sesion, dto: CrearEmpleadoDto) {
    // EL HASH VA AFUERA DE LA TRANSACCION. argon2 tarda ~100 ms a proposito
    // y no toca la base: adentro seria tener una conexion del pool
    // secuestrada y una transaccion abierta sin hacer nada.
    const codigo = dto.usuario ? generarCodigo() : null;
    const codigoHash = codigo
      ? await argon2.hash(codigo.paraHash, { type: argon2.argon2id })
      : null;

    const r = await this.prisma.conSesion(sesion, async (tx) => {
      await this.exigirAdministrar(tx);

      // 1 - El empleado.
      //
      // empresa_id sale de core.empresa_actual(), NUNCA del cuerpo de la
      // peticion. Y no hay comprobacion de permiso escrita aqui porque
      // rls_empleado_crear ya exige empresa, sesion vigente y puede_crear():
      // si la empresa quedo en solo_lectura, este INSERT revienta solo.
      const [emp] = await tx.$queryRaw<{ empleado_id: bigint }[]>`
        INSERT INTO core.empleado
          (empresa_id, nombres, apellidos, documento, telefono, correo,
           cargo, numero_colegiacion, activo)
        VALUES
          ((SELECT core.empresa_actual()),
           ${dto.nombres.trim()},
           ${dto.apellidos.trim()},
           ${dto.documento?.trim() || null},
           ${dto.telefono?.trim() || null},
           ${dto.correo?.trim() || null},
           ${dto.cargo?.trim() || null},
           ${dto.numeroColegiacion?.trim() || null},
           ${dto.activo ?? true})
        RETURNING empleado_id`;

      let usuarioId: bigint | null = null;
      let venceEn: Date | null = null;

      if (dto.usuario && codigoHash) {
        // 2 - La cuenta. Nace en pendiente_activacion y sin clave: el
        //     password_hash queda en '', que no es el hash de nada.
        const [u] = await tx.$queryRaw<{ crear_usuario: bigint }[]>`
          SELECT core.crear_usuario(
            ${emp.empleado_id},
            ${BigInt(dto.usuario.rolId)},
            ${dto.usuario.username.trim().toLowerCase()})`;
        usuarioId = u.crear_usuario;

        // 3 - El codigo de un solo uso. La base guarda el HASH; el codigo en
        //     claro solo existe en esta respuesta, una vez.
        const [act] = await tx.$queryRaw<{ vence_en: Date }[]>`
          SELECT * FROM core.generar_activacion(
            ${usuarioId}, ${codigoHash}, ${dto.usuario.horas ?? 24})`;
        venceEn = act.vence_en;

        // 4 - Las sedes donde va a poder pararse. Sin esto la cuenta nace
        //     rota: abrirSesion() rechaza a quien no tiene ninguna sucursal
        //     activa, asi que podria activar su clave y aun asi no entrar.
        //
        //     El INSERT saca empresa_id de core.sucursal, no del cuerpo de
        //     la peticion -- y RLS ya recorto esa tabla a la empresa de la
        //     sesion, asi que una sede ajena no aparece y no se puede colar.
        //     Si el arreglo trae un id inventado, simplemente no inserta esa
        //     fila; por eso abajo se cuenta lo insertado.
        const lista = '{' + dto.usuario.sucursales.join(',') + '}';

        const dadas = await tx.$queryRaw<{ sucursal_id: bigint }[]>`
          INSERT INTO core.acceso_sucursal (usuario_id, sucursal_id, empresa_id)
          SELECT ${usuarioId}, s.sucursal_id, s.empresa_id
            FROM core.sucursal s
           WHERE s.sucursal_id = ANY(${lista}::bigint[])
             AND s.activo
          RETURNING sucursal_id`;

        if (dadas.length === 0) {
          throw new BadRequestException(
            'Ninguna de esas sucursales existe o esta abierta en tu empresa',
          );
        }
      }

      // 5 - Se relee con la MISMA forma que usa la lista, para que el front
      //     reciba un objeto identico venga de donde venga.
      const [fila] = await tx.$queryRawUnsafe<{ empleado: EmpleadoDeLista }[]>(
        `SELECT ${FORMA_EMPLEADO} AS empleado ${DESDE_EMPLEADO} WHERE e.empleado_id = $1`,
        emp.empleado_id,
      );

      return { empleado: fila.empleado, usuarioId, venceEn };
    });

    return {
      ...r.empleado,

      // EL CODIGO EN CLARO, Y ES LA UNICA VEZ QUE EXISTE.
      //
      // En la base solo queda su hash argon2: no hay pantalla de "ver el
      // codigo otra vez" ni la va a haber. Si se pierde, se genera otro con
      // POST /usuarios/:id/resetear-clave.
      activacion: codigo
        ? {
            codigo: codigo.legible,
            venceEn: r.venceEn,
            aviso: 'Este codigo no se vuelve a mostrar. Entregaselo a la persona.',
          }
        : null,
    };
  }

  // ===================================================================
  //  EDITAR
  // ===================================================================
  async actualizar(sesion: Sesion, id: number, dto: ActualizarEmpleadoDto) {
    return this.prisma.conSesion(sesion, async (tx) => {
      await this.exigirAdministrar(tx);

      // Sin WHERE empresa_id: rls_empleado_editar pone el USING (que filas
      // puede tocar) y el WITH CHECK (como puede quedar la fila). Si la
      // empresa esta en solo_lectura, puede_modificar() lo rechaza solo.
      const filas = await tx.$queryRaw<{ empleado_id: bigint }[]>`
        UPDATE core.empleado SET
          nombres            = ${dto.nombres.trim()},
          apellidos          = ${dto.apellidos.trim()},
          documento          = ${dto.documento?.trim() || null},
          telefono           = ${dto.telefono?.trim() || null},
          correo             = ${dto.correo?.trim() || null},
          cargo              = ${dto.cargo?.trim() || null},
          numero_colegiacion = ${dto.numeroColegiacion?.trim() || null},
          activo             = ${dto.activo ?? true}
        WHERE empleado_id = ${BigInt(id)}
        RETURNING empleado_id`;

      // Cero filas puede ser "no existe" o "es de otra empresa": para quien
      // pregunta son lo mismo, y tiene que seguir siendolo.
      if (filas.length === 0) throw new NotFoundException('No existe ese empleado');

      const [fila] = await tx.$queryRawUnsafe<{ empleado: EmpleadoDeLista }[]>(
        `SELECT ${FORMA_EMPLEADO} AS empleado ${DESDE_EMPLEADO} WHERE e.empleado_id = $1`,
        BigInt(id),
      );

      return fila.empleado;
    });
  }

  // ===================================================================
  //  ROLES - para el desplegable del formulario
  // ===================================================================
  async listarRoles(sesion: Sesion): Promise<RolDeLista[]> {
    return this.prisma.conSesion(sesion, async (tx) => {
      await this.exigirAdministrar(tx);

      const [fila] = await tx.$queryRaw<{ lista: RolDeLista[] }[]>`
        SELECT coalesce(jsonb_agg(x ORDER BY x->>'nombre'), '[]'::jsonb) AS lista
        FROM (
          SELECT jsonb_build_object(
                   'rolId',       r.rol_id,
                   'nombre',      r.nombre,
                   'descripcion', r.descripcion,
                   'esSistema',   r.es_sistema
                 ) AS x
          FROM core.rol r
        ) q`;

      return fila?.lista ?? [];
    });
  }

  // ===================================================================
  //  SUCURSALES - para las casillas del formulario
  // ===================================================================
  async listarSucursales(sesion: Sesion): Promise<SucursalDeLista[]> {
    return this.prisma.conSesion(sesion, async (tx) => {
      await this.exigirAdministrar(tx);

      // Solo las ABIERTAS: dar acceso a una sede cerrada es dar acceso a
      // nada, y la lista de sesion las filtra igual.
      const [fila] = await tx.$queryRaw<{ lista: SucursalDeLista[] }[]>`
        SELECT coalesce(jsonb_agg(x ORDER BY x->>'codigo'), '[]'::jsonb) AS lista
        FROM (
          SELECT jsonb_build_object(
                   'sucursalId', s.sucursal_id,
                   'codigo',     s.codigo,
                   'nombre',     s.nombre
                 ) AS x
          FROM core.sucursal s
          WHERE s.activo
        ) q`;

      return fila?.lista ?? [];
    });
  }

  // ===================================================================
  //  Lo comun
  //
  //  EL PERMISO, DOS VECES Y A PROPOSITO.
  //
  //  Aqui se pregunta para poder contestar un 403 con un mensaje que se
  //  entienda. Despues, core.exigir_permiso() lo vuelve a exigir dentro de
  //  la misma transaccion: esa es la ultima linea de defensa, la que atrapa
  //  el endpoint que alguien escriba manana sin acordarse de esta
  //  comprobacion. Su propio comentario en 04_funciones.sql lo dice.
  //
  //  Se usa usuario_puede() y no usuario_puede_en() porque los empleados y
  //  los roles son de la EMPRESA, no de una sede: un empleado no "esta" en
  //  una sucursal. Para lo que si ocurre en una sede -- una orden, una
  //  muestra -- va la estricta.
  // ===================================================================
  private async exigirAdministrar(tx: Tx): Promise<void> {
    const permiso = await tx.$queryRaw<{ puede: boolean }[]>`
      SELECT core.usuario_puede('usuario.administrar') AS puede`;

    if (!permiso[0]?.puede) {
      throw new ForbiddenException('No tenes permiso para administrar empleados');
    }

    // EL ::text NO SOBRA, y si alguien lo quita esto vuelve a romperse.
    //
    // core.exigir_permiso() devuelve void. Prisma intenta deserializar cada
    // columna que vuelve y no sabe que hacer con el tipo void:
    //
    //   Failed to deserialize column of type 'void'
    //
    // El cast la convierte en una cadena vacia, que si sabe leer. La funcion
    // corre igual y su RAISE sigue subiendo -- lo unico que cambia es el
    // envoltorio de lo que devuelve, que de todos modos no se mira.
    await tx.$queryRaw`SELECT core.exigir_permiso('usuario.administrar')::text AS ok`;
  }
}
