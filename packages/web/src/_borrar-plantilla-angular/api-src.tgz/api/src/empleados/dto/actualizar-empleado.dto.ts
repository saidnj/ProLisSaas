import {
  IsBoolean, IsEmail, IsOptional, IsString, MaxLength, MinLength,
} from 'class-validator';

/**
 * Editar es el mismo formulario que crear, MENOS la cuenta.
 *
 * Los campos van escritos otra vez en vez de heredar de CrearEmpleadoDto
 * quitando 'usuario' -- que seria mas corto -- por dos razones:
 *
 *   1. No hace falta instalar @nestjs/mapped-types para ocho campos.
 *   2. Al no existir 'usuario' en esta clase, el ValidationPipe (que corre
 *      con forbidNonWhitelisted) rechaza con un 400 a quien lo mande. Si
 *      heredara y lo ignorara en el servicio, el cliente creeria que cambio
 *      el rol de alguien y no paso nada. Fallar ruidoso es mejor.
 *
 * La cuenta no se toca aqui a proposito: crear un usuario, cambiarle el rol
 * o resetearle la clave son acciones con sus propias reglas y su propio
 * rastro. Meterlas en el "guardar" del empleado haria que un cambio de
 * telefono y un cambio de permisos se vieran igual en la auditoria.
 *
 * OJO con la semantica: el front manda el objeto COMPLETO, y lo que no venga
 * queda en null. No es un parche campo por campo.
 */
export class ActualizarEmpleadoDto {
  @IsString()
  @MinLength(2, { message: 'Hace falta el nombre' })
  @MaxLength(80)
  nombres!: string;

  @IsString()
  @MinLength(2, { message: 'Hacen falta los apellidos' })
  @MaxLength(80)
  apellidos!: string;

  @IsOptional() @IsString() @MaxLength(30)
  documento?: string;

  @IsOptional() @IsString() @MaxLength(30)
  telefono?: string;

  @IsOptional() @IsEmail({}, { message: 'Ese correo no tiene forma de correo' })
  correo?: string;

  @IsOptional() @IsString() @MaxLength(80)
  cargo?: string;

  @IsOptional() @IsString() @MaxLength(40)
  numeroColegiacion?: string;

  @IsOptional() @IsBoolean()
  activo?: boolean;
}
