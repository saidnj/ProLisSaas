import { Body, Controller, Get, Param, ParseIntPipe, Patch, Post } from '@nestjs/common';
import { EmpleadosService } from './empleados.service';
import { CrearEmpleadoDto } from './dto/crear-empleado.dto';
import { ActualizarEmpleadoDto } from './dto/actualizar-empleado.dto';
import { SesionActual } from '../comun/sesion.decorador';
// 'import type' por isolatedModules + emitDecoratorMetadata: un tipo que
// aparece en una firma decorada se importa como tipo, si no TypeScript
// intenta emitir metadata de runtime para una interfaz que no existe ahi.
import type { Sesion } from '../comun/sesion';

/**
 * Sin @Publico(): el guard global ya las cerro. Y la sesion no llega del
 * cuerpo ni de la URL -- sale del token firmado, via @SesionActual().
 */
@Controller('empleados')
export class EmpleadosController {
  constructor(private readonly empleados: EmpleadosService) {}

  /** GET /empleados - la lista de la empresa de quien pregunta. */
  @Get()
  listar(@SesionActual() sesion: Sesion) {
    return this.empleados.listar(sesion);
  }

  /**
   * POST /empleados - crea el empleado y, si viene el bloque "usuario",
   * tambien su cuenta y su codigo de activacion. Las tres cosas en una sola
   * transaccion.
   *
   * Devuelve 201 (el 'created' de siempre) y el codigo EN CLARO una unica
   * vez: de la base solo sale el hash.
   */
  @Post()
  crear(@SesionActual() sesion: Sesion, @Body() dto: CrearEmpleadoDto) {
    return this.empleados.crear(sesion, dto);
  }

  /** GET /empleados/:id - la ficha de uno. */
  @Get(':id')
  obtener(@SesionActual() sesion: Sesion, @Param('id', ParseIntPipe) id: number) {
    return this.empleados.obtener(sesion, id);
  }

  /** PATCH /empleados/:id - editar sus datos. No toca su cuenta. */
  @Patch(':id')
  actualizar(
    @SesionActual() sesion: Sesion,
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: ActualizarEmpleadoDto,
  ) {
    return this.empleados.actualizar(sesion, id, dto);
  }
}
