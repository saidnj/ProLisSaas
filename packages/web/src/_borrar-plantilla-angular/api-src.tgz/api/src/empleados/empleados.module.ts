import { Module } from '@nestjs/common';
import { EmpleadosController } from './empleados.controller';
import { RolesController } from './roles.controller';
import { SucursalesController } from './sucursales.controller';
import { EmpleadosService } from './empleados.service';

@Module({
  controllers: [EmpleadosController, RolesController, SucursalesController],
  providers: [EmpleadosService],
})
export class EmpleadosModule {}
