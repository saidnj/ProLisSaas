import { Type } from 'class-transformer';
import {
  ArrayNotEmpty, IsArray, IsBoolean, IsEmail, IsInt, IsOptional, IsPositive,
  IsString, MaxLength, MinLength, ValidateNested,
} from 'class-validator';

/**
 * La parte OPCIONAL: la cuenta para entrar al sistema.
 *
 * Opcional porque no todo empleado lleva usuario. El motorista y la senora
 * del aseo trabajan en el laboratorio y no entran al sistema; obligar a
 * darles credencial seria crear cuentas que nadie usa y que igual hay que
 * cuidar.
 */
export class CuentaNuevaDto {
  @IsString()
  @MinLength(3, { message: 'El usuario necesita al menos 3 caracteres' })
  @MaxLength(40)
  username!: string;

  @Type(() => Number)
  @IsInt({ message: 'Hace falta elegir un rol' })
  @IsPositive()
  rolId!: number;

  /**
   * En que sedes va a poder pararse. AL MENOS UNA.
   *
   * No es opcional y no tiene valor por omision a proposito: un usuario sin
   * ninguna sucursal activa no puede entrar a ningun lado -- abrirSesion()
   * lo rechaza con "No tenes ninguna sucursal activa asignada". Crearlo asi
   * seria fabricar una cuenta rota que nadie sabe por que no funciona.
   */
  @IsArray()
  @ArrayNotEmpty({ message: 'Hace falta elegir al menos una sucursal' })
  @Type(() => Number)
  @IsInt({ each: true })
  @IsPositive({ each: true })
  sucursales!: number[];

  /**
   * Cuantas horas vive el codigo de activacion. La base lo acota entre 1 y
   * 168 (siete dias) y revienta con 22023 si se pasa.
   */
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  horas?: number;
}

export class CrearEmpleadoDto {
  @IsString()
  @MinLength(2, { message: 'Hace falta el nombre' })
  @MaxLength(80)
  nombres!: string;

  @IsString()
  @MinLength(2, { message: 'Hacen falta los apellidos' })
  @MaxLength(80)
  apellidos!: string;

  /** Numero de identidad. Opcional: no todos lo traen el primer dia. */
  @IsOptional() @IsString() @MaxLength(30)
  documento?: string;

  @IsOptional() @IsString() @MaxLength(30)
  telefono?: string;

  @IsOptional() @IsEmail({}, { message: 'Ese correo no tiene forma de correo' })
  correo?: string;

  @IsOptional() @IsString() @MaxLength(80)
  cargo?: string;

  /** Del bioquimico o del medico. Va impreso en el informe junto a la firma. */
  @IsOptional() @IsString() @MaxLength(40)
  numeroColegiacion?: string;

  @IsOptional() @IsBoolean()
  activo?: boolean;

  @IsOptional()
  @ValidateNested()
  @Type(() => CuentaNuevaDto)
  usuario?: CuentaNuevaDto;
}
