import { Controller, Get } from '@nestjs/common';
import { EmpleadosService } from './empleados.service';
import { SesionActual } from '../comun/sesion.decorador';
import type { Sesion } from '../comun/sesion';

/**
 * GET /sucursales - las sedes ABIERTAS de la empresa, para las casillas del
 * formulario de empleado.
 *
 * Vive aqui por lo mismo que roles.controller.ts: es lo unico que hace falta
 * de sucursales hoy. Cuando tengan pantalla propia -- abrir una sede,
 * configurarla -- se mudan a packages/api/src/sucursales.
 */
@Controller('sucursales')
export class SucursalesController {
  constructor(private readonly empleados: EmpleadosService) {}

  @Get()
  listar(@SesionActual() sesion: Sesion) {
    return this.empleados.listarSucursales(sesion);
  }
}
