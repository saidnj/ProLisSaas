import { Controller, Get } from '@nestjs/common';
import { EmpleadosService } from './empleados.service';
import { SesionActual } from '../comun/sesion.decorador';
import type { Sesion } from '../comun/sesion';

/**
 * GET /roles - para el desplegable del formulario de empleado.
 *
 * Vive aqui porque es lo unico que hace falta de roles hoy y crear un modulo
 * entero para una consulta es ruido. Cuando los roles tengan su propia
 * pantalla -- crear roles, marcar permisos -- se mudan a packages/api/src/roles.
 */
@Controller('roles')
export class RolesController {
  constructor(private readonly empleados: EmpleadosService) {}

  @Get()
  listar(@SesionActual() sesion: Sesion) {
    return this.empleados.listarRoles(sesion);
  }
}
