import {
  ArgumentsHost, Catch, ExceptionFilter, HttpException,
  HttpStatus, Logger,
} from '@nestjs/common';
import { Response } from 'express';

/**
 * Traduce los errores que sube la BASE a respuestas HTTP.
 *
 * El caso que importa es el 28000, que lanza core.sesion_vigente() desde
 * adentro de las politicas RLS cuando el usuario o su empresa dejaron de
 * estar habilitados. Sin este filtro llegaria al front como un 500, y el
 * errorInterceptor de Angular no sabria que tiene que mandar al login.
 *
 *   base            core.sesion_vigente() -> RAISE ... ERRCODE '28000'
 *   aqui            28000 -> 401 { mensaje, pista }
 *   angular         errorInterceptor ve el 401 -> cierra sesion -> /login
 */
@Catch()
export class ErroresBaseFilter implements ExceptionFilter {
  private readonly log = new Logger('ErroresBase');

  catch(exc: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse<Response>();

    // Lo que ya es una excepcion de Nest pasa de largo.
    if (exc instanceof HttpException) {
      return res.status(exc.getStatus()).json(exc.getResponse());
    }

    const { sqlstate, mensaje, pista } = this.leerErrorDePostgres(exc);

    if (sqlstate === '28000') {
      return res.status(HttpStatus.UNAUTHORIZED).json({
        statusCode: 401,
        message: mensaje ?? 'Sesion caducada',
        hint: pista,
      });
    }

    // Cualquier otra cosa: se registra entera del lado del servidor y al
    // cliente le va un 500 pelado. Un error de base sin filtrar puede
    // llevar nombres de tablas, columnas y hasta valores de otras filas.
    this.log.error(exc);
    return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
      statusCode: 500,
      message: 'Error interno',
    });
  }

  /**
   * Prisma envuelve los errores de SQL crudo, y el SQLSTATE no siempre cae
   * en el mismo sitio segun como se haya hecho la consulta. Se miran los
   * lugares conocidos en orden.
   *
   * OJO: esto hay que confirmarlo con el error de verdad la primera vez,
   * registrando el objeto entero. Si el 28000 llega y aun asi sale un 500,
   * es que cae en una ruta que no esta en esta lista.
   */
  private leerErrorDePostgres(exc: any) {
    const sqlstate: string | undefined =
      exc?.meta?.code ??            // PrismaClientKnownRequestError P2010
      exc?.code ??                  // driver pg directo
      exc?.originalError?.code ??
      exc?.cause?.code;

    const mensaje: string | undefined =
      exc?.meta?.message ?? exc?.message;

    const pista: string | undefined =
      exc?.meta?.hint ?? exc?.hint ?? exc?.originalError?.hint;

    return { sqlstate, mensaje, pista };
  }
}
